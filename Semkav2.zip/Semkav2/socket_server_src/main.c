#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "buffer.h"
#include "pos_sockets/char_buffer.h"
#include "pos_sockets/active_socket.h"
#include "pos_sockets/passive_socket.h"

typedef struct world {
} WORLD;

GENERATE_BUFFER(struct world, world);

typedef struct thread_data {
    pthread_mutex_t mutex;
    pthread_cond_t is_full;
    pthread_cond_t is_empty;
    char *mapa;

    short port; // port
    ACTIVE_SOCKET* my_socket;   // socket
} THREAD_DATA;

void thread_data_init(struct thread_data* data,
        short port, ACTIVE_SOCKET* my_socket) {
    pthread_mutex_init(&data->mutex, NULL);
    pthread_cond_init(&data->is_full, NULL);
    pthread_cond_init(&data->is_empty, NULL);

    data->port = port;
    data->my_socket = my_socket;
}

void thread_data_destroy(struct thread_data* data) {
    pthread_mutex_destroy(&data->mutex);
    pthread_cond_destroy(&data->is_full);
    pthread_cond_destroy(&data->is_empty);

    data->port = 0;
    data->my_socket = NULL;
}

_Bool world_data_try_write(struct char_buffer* buf) {
    char * pos = strchr(buf->data, ';');
    if (pos != NULL) {
        pos = strchr(pos + 1, ';');
        if (pos != NULL) {
            for (int i = 0; i < buf->size; i++) {
                printf("%c", buf->data[i]);
            }
            return true;
        }
    }
    return false;
}

_Bool try_get_client_world_data(struct active_socket* my_sock) {
    _Bool result = false;
    CHAR_BUFFER r_buff;
    char_buffer_init(&r_buff);

    if (active_socket_try_get_read_data(my_sock, &r_buff)) {
        if (r_buff.size > 0) {
            if (active_socket_is_end_message(my_sock, &r_buff)) {
                active_socket_stop_reading(my_sock);
            } else if (world_data_try_write(&r_buff)) {
                result = true;
            } else {
                active_socket_stop_reading(my_sock);
            }
        }
    }
    char_buffer_destroy(&r_buff);

    return result;
}

void* process_client_data(void* thread_data) {
    struct thread_data * data = thread_data;

    PASSIVE_SOCKET p_socket;
    passive_socket_init(&p_socket);
    passive_socket_start_listening(&p_socket, data->port);

    passive_socket_wait_for_client(&p_socket, data->my_socket);

    passive_socket_stop_listening(&p_socket);
    passive_socket_destroy(&p_socket);
    printf("Klient bol pripojeny!\n");

    active_socket_start_reading(data->my_socket);
    try_get_client_world_data(data->my_socket);

    return NULL;
}

void ziskaj_mapu(ACTIVE_SOCKET* socket, char* data) {
    struct char_buffer receivedBuffer;
    char_buffer_init(&receivedBuffer);
    if (active_socket_try_get_read_data(socket, &receivedBuffer)) {
        if (receivedBuffer.size > 0) {
            data = receivedBuffer.data;
            printf("Uspesne som prijal svet.");
            printf("%s", receivedBuffer.data);
        }
    }
}

void consume(struct thread_data data) {
    while (true) {
        sleep(1);
        ziskaj_mapu(data.my_socket, &data.mapa);
    }
}

int main(int argc, char* argv[]) {

    pthread_t th_receive;
    struct thread_data data;
    struct active_socket my_socket;
    active_socket_init(&my_socket);
    thread_data_init(&data, 11130, &my_socket);
    pthread_create(&th_receive, NULL, process_client_data, &data);

    consume(data);
    pthread_join(th_receive, NULL);

    thread_data_destroy(&data);
    active_socket_destroy(&my_socket);
    return 0;
}
