#ifndef SIMULACIA_H
#define SIMULACIA_H

#include "Mapa.h"
#include "MySocket.h"

class Simulacia {
private:
    int pocetDni;
    Mapa mapa;
    MySocket* serverSocket{};

public:
    Simulacia(int a, int b);
    ~Simulacia();
    void simuluj();
    void odosliSvet(const std::string& retazec);
    void nastavOhen();
};

#endif // SIMULACIA_H
