#include "Simulacia.h"
#include <iostream>

Simulacia::Simulacia(int a, int b) : mapa(a, b) {
    this->pocetDni = 0;
    //MySocket* mySocket = MySocket::createConnection("frios2.fri.uniza.sk", 19120);
    MySocket::createConnection("frios2.fri.uniza.sk", 19120);
}

Simulacia::~Simulacia() {
    delete serverSocket;
    serverSocket = nullptr;
}

void Simulacia::simuluj() {
    int vstup = 0;
    int pocetKolVetra = 0;

    while (vstup != 3) {
        std::cout << "Zadaj vstup ! (1 = pokracovat, 2 = zadat ohen, 3 = ukoncit, 4 = ulozit do suboru, 5 = nacitaj zo suboru)" << std::endl;
        std::cin >> vstup;

        if (vstup == 1) {
            if (pocetKolVetra >= 2) {
                mapa.setSmerVetru(5);
                pocetKolVetra = 0;
            }

            if (mapa.getBezvetrie()) {
                if (mapa.random(0, 100) < 10) {
                    mapa.spawniVietor();
                }
            } else {
                pocetKolVetra++;
            }
            mapa.krok();
            pocetDni++;
            std::cout << "pocet kol vetra: " << pocetKolVetra << std::endl;
            this->odosliSvet(mapa.getAktualnySvet());
        }

        if (vstup == 2) {
            nastavOhen();
        }

        if (vstup == 4) {
            mapa.ulozDoSuboru();
        }

        if (vstup == 5) {
            mapa.nacitajZoSuboru();
        }
    }
    std::cout << "Ukoncujem aplikaciu." << std::endl;
}

void Simulacia::nastavOhen() {
    std::cout << "Zadaj pociatocny ohen!" << std::endl;
    int x, y;
    std::cin >> x;
    std::cin >> y;
    mapa.nastavPociatocnyOhen(x, y);
}

void Simulacia::odosliSvet(const std::string& retazec) {
    this->serverSocket->sendData(retazec);
}