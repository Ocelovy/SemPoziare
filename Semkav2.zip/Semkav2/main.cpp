#include <random>
#include "Simulacia.h"

using namespace std;

int main(int argc, char* argv[]) {

    Simulacia simulacia(atoi(argv[1]), atoi(argv[2]));

    std::thread t1(&Simulacia::simuluj, &simulacia);

    std::thread t2(&Simulacia::dajVstup, &simulacia);

    t2.join();

    std::unique_lock<std::mutex> lock(simulacia.getMutex());
    simulacia.setInputRecived(true);
    lock.unlock();
    simulacia.getConditionVariable().notify_one();
    t1.join();

    return 0;
}