#include <random>
#include "Simulacia.h"

using namespace std;

int main(int argc, char* argv[]) {

    Simulacia simulacia(atoi(argv[1]), atoi(argv[2]));
    simulacia.simuluj();

    return 0;
}